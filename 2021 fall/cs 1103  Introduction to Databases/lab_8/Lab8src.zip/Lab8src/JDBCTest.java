import java.sql.Connection;
import java.sql.DriverManager;

class JDBCTest {

    final String url = "jdbc:mysql://cs1103.cs.unb.ca:3306/YoUr dAtAbAsE hErE";
    final String user = "YoUr uSeRnAmE hErE";
    final String password = "YoUr pAsSwOrD hErE";

    public static void main(String args[]) {
        try {
            Connection con = DriverManager.getConnection(url, user, password);
            System.out.println("Success");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

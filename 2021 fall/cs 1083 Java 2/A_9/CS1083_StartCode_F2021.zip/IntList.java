/**
Defines a class that represents a list of integers
*/
public class IntList {

	/**
	First node in the list
	*/
	private IntNode front; 

	/**
	Constructs a list.  Initially the list is empty.
	*/
	public IntList() {
		front = null;
	}

	/**
	Adds given integer to front of list.
	@param val integer to add to the front of the list
	*/
	public void addToFront(int val) {
		front = new IntNode(val, front);
	}

	/**
	Removes the first node from the list.
	If the list is empty, does nothing.
	*/
	public void removeFirst() {
		if (front != null) {
			front = front.next;
		}
	}

	/**
	Prints the list elements from first to last.
	*/
	public void print() {
		System.out.println("--------------------");
		System.out.print("List elements: ");
		IntNode temp = front;
		while (temp != null) {
			System.out.print(temp.val + " ");
			temp = temp.next;
		}
		System.out.println("\n-----------------------\n");
	}

	
	/**
	An inner class that represents a node in the integer list.
	The public variables are accessed by the IntList class.
	*/
	private class IntNode {
		
		/**
		Value stored in node.
		*/
		public int val; 
		
		/**
		Link to next node in list.
		*/
		public IntNode next; 
		
		/**
		Constructor; sets up the node given a value and IntNode reference
		@param val the value to store in the node
		@param next the link to the next node in the list
		*/
		public IntNode(int val, IntNode next) {
			this.val = val;
			this.next = next;
		}
	}
}


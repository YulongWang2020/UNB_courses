import java.util.Scanner;
import java.util.InputMismatchException;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.io.File;

/**
* Creates a report on movies.
*/
public class MovieReporter
{
	public static void main(String[] args)
	{
		//create a set to organize Genres
		GenreSet genres = new GenreSet();
	
		
	}
}
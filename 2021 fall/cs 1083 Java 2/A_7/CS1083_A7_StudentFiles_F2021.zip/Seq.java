/**
Seq.java
A utility class that provide methods to compute elements of the
recursive sequence.
*/
public class Seq{
	
	/**
	Recursively computes seq(n)
	@param n Non-negative integer.
	@return int Element n in the recursive sequence.
	*/
	public static int seqR(int n){
		//Fill in code -- this should look very much like the
		//mathematical specification
		
	}
	
}
